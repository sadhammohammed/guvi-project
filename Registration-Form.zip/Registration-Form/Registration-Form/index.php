<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="initial-scale=1.0, maximum-scale=2.0">
<title> Registration and Signin  </title>
		
<link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
		
</head>

	<body>
	
	<nav class="navbar navbar-default navbar-static-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav">
            <li class="active"><a href="">Register</a></li>
			<li><a href="" style="color:white">Sigin</a></li>
          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </nav>
	
	<div class="wrapper">
	<div class="container">
		<div class="col-lg-12">
		  
			<center><h2>Registration Here</h2></center>
			
			<form id="registraion_form" class="form-horizontal">
					
				<div class="form-group">
			
				<label class="col-sm-3 control-label">Username</label>
				<div class="col-sm-6">
				<input type="text" id="txt_username" class="form-control" placeholder="enter username" />
				</div>
				</div>
				
				<div class="form-group">
				<label class="col-sm-3 control-label">Email</label>
				<div class="col-sm-6">
				<input type="text" id="txt_email" class="form-control" placeholder="enter email" />
				</div>
				</div>
				
				<div class="form-group">
				<label class="col-sm-3 control-label">Password</label>
				<div class="col-sm-6">
				<input type="password" id="txt_password" class="form-control" placeholder="enter password" />
				</div>
				</div>
				
				<div class="form-group">
				<div class="col-sm-offset-3 col-sm-6 m-t-15">
				<button type="submit" id="btn_register" class="btn btn-success">Register</button>
				</div>
				</div>
				
				<div class="form-group">
					<div id="message" class="col-sm-offset-3 col-sm-6 m-t-15"></div>
				</div>
			
			</form>
			
		</div>
	</div>	
	</div>
	
	<script src="js/jquery-1.12.4-jquery.min.js"></script>
	<script src="bootstrap/js/bootstrap.min.js"></script>
	
	<script>
		
		$(document).on('click','#btn_register',function(e){
			
			e.preventDefault();
			
			var username = $('#txt_username').val();
			var email 	 = $('#txt_email').val();
			var password = $('#txt_password').val();
			
			var atpos  = email.indexOf('@');
			var dotpos = email.lastIndexOf('.com');
			
			if(username == ''){ // check username not empty
				alert('please enter username !!'); 
			}
			
			else if(email == ''){ //check email not empty
				alert('please enter email address !!'); 
			}
			else if(atpos < 1 || dotpos < atpos + 2 || dotpos + 2 >= email.length){ //check valid email format
				alert('please enter valid email address !!'); 
			}
			else if(password == ''){ //check password not empty
				alert('please enter password !!'); 
			}
			else if(password.length < 6){ //check password value length six 
				alert('password must be 6 !!');
			} 
			else{			
				$.ajax({
					url: 'process.php',
					type: 'post',
					data: 
						{newusername:username, 
						 newemail:email, 
						 newpassword:password
						},
					success: function(response){
						$('#message').html(response);
					}
				});
				
				$('#registraion_form')[0].reset();
			}
		});

	</script>
	
	</body>
</html>

